import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter, withInMemoryScrolling } from '@angular/router';

import { routes } from './app.routes';
import { adminAuthInterceptor } from './services/admin-auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    // كل طلبات HttpClient تمر من interceptor الذي يضيف JWT لمسارات Admin فقط.
    // طلبات الحجز العامة لا تحتاج رمز إدارة.
    provideHttpClient(withInterceptors([adminAuthInterceptor])),
    // المسارات lazy-loaded لتفادي تحميل صفحات Admin والحجز قبل أن يطلبها المستخدم.
    provideRouter(
      routes,
      withInMemoryScrolling({
        anchorScrolling: 'enabled',
        scrollPositionRestoration: 'enabled',
      }),
    ),
  ],
};
