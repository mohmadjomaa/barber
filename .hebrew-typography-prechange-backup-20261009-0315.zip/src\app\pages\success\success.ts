import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnDestroy, OnInit, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { getApiErrorMessage } from '../../services/api-error';
import { BookingApiService } from '../../services/booking-api';
import { BookingStateService } from '../../services/booking-state';

@Component({
  selector: 'app-success',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './success.html',
  styleUrl: './success.css'
})
export class Success implements OnInit, OnDestroy {
  private bookingState = inject(BookingStateService);
  private bookingApi = inject(BookingApiService);
  private changeDetectorRef = inject(ChangeDetectorRef);
  private router = inject(Router);
  private redirectTimer: ReturnType<typeof setTimeout> | null = null;
  booking: import('../../services/booking-state').BookingRecord | null = null;
  deletedMessage = '';
  secondsUntilHome = 5;

  async ngOnInit() {
    const lastBookingId = this.bookingState.getLastBookingId();

    if (!lastBookingId) {
      return;
    }

    const token = this.bookingState.getBookingToken(lastBookingId);

    if (!token) {
      this.booking = null;
      return;
    }

    try {
      this.booking = await firstValueFrom(this.bookingApi.getBooking(lastBookingId, token));
      this.bookingState.setBookings([this.booking]);
    } catch {
      this.booking = null;
    }

    this.changeDetectorRef.markForCheck();

    if (this.booking) {
      this.redirectTimer = setTimeout(() => this.router.navigate(['/']), this.secondsUntilHome * 1000);
    }
  }

  ngOnDestroy() {
    if (this.redirectTimer) {
      clearTimeout(this.redirectTimer);
    }
  }

  get formattedDate() {
    return this.booking ? this.bookingState.formatDate(this.booking.date) : '';
  }

  get reminderLabel() {
    const method = this.booking?.reminderPreference || 'sms';
    const label = method === 'whatsapp' ? 'WhatsApp' : method === 'email' ? 'email' : 'SMS';
    return `${label} reminder scheduled 24 hours before.`;
  }

  repeatLastBooking() {
    this.bookingState.applyLastBooking();
  }

  async deleteBooking() {
    if (!this.booking) {
      return;
    }

    if (this.redirectTimer) {
      clearTimeout(this.redirectTimer);
      this.redirectTimer = null;
    }

    if (!window.confirm('Delete this booking? This action cannot be undone.')) {
      return;
    }

    const bookingId = this.booking.id;
    const token = this.bookingState.getBookingToken(bookingId);

    try {
      await firstValueFrom(this.bookingApi.deleteBooking(bookingId, token));
      this.bookingState.clearBookingReference(bookingId);
      this.booking = null;
      this.deletedMessage = 'Your booking has been deleted.';
    } catch (error) {
      this.deletedMessage = getApiErrorMessage(error, 'We could not delete this booking. Please call the shop.');
    }
  }
}
