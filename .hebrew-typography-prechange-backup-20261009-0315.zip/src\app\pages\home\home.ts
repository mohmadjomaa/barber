import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { BookingApiService } from '../../services/booking-api';
import { BookingRecord, BookingStateService } from '../../services/booking-state';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home implements OnInit {
  private bookingState = inject(BookingStateService);
  private bookingApi = inject(BookingApiService);
  services = this.bookingState.services;
  barbers = this.bookingState.barbers;
  lastBooking = this.bookingState.getLastBooking();
  recommendedService = this.bookingState.services[0];
  nextSlot = { date: '', time: '' };
  confirmationBooking = (history.state?.['confirmedBooking'] as BookingRecord | undefined) || null;

  async ngOnInit() {
    try {
      const [services, barbers, dates] = await Promise.all([
        firstValueFrom(this.bookingApi.getServices()),
        firstValueFrom(this.bookingApi.getBarbers()),
        firstValueFrom(this.bookingApi.getAvailabilityDates(1))
      ]);
      this.bookingState.setServices(services);
      this.bookingState.setBarbers(barbers);
      this.services = this.bookingState.services;
      this.barbers = this.bookingState.barbers;
      this.recommendedService = this.services[0] || this.recommendedService;
      const nextDate = dates[0]?.iso || '';
      const slotGroups = await firstValueFrom(this.bookingApi.getAvailabilitySlots({
        date: nextDate,
        serviceId: this.recommendedService?.id || null,
        barberId: null,
        barberPreference: 'any'
      }));
      const nextTime = slotGroups.flatMap(group => group.slots).find(slot => !slot.disabled)?.time || '';
      this.nextSlot = { date: nextDate, time: nextTime };
    } catch {}
  }

  startBooking(serviceId?: string) {
    this.bookingState.startNewBooking({
      barberPreference: 'any',
      ...(serviceId ? { serviceId } : {})
    });
    this.bookingState.track('start_booking', { mode: serviceId ? 'service_preview' : 'hero_cta', serviceId: serviceId || null });
  }

  repeatLastBooking() {
    this.bookingState.applyLastBooking();
  }

  get previewServices() {
    return this.services.slice(0, 3);
  }

  get lastBookingLabel() {
    return this.lastBooking
      ? `${this.lastBooking.service} with ${this.lastBooking.barber}`
      : '';
  }

  get formattedNextSlot() {
    return this.bookingState.formatDate(this.nextSlot.date);
  }

  get confirmationMessage() {
    if (!this.confirmationBooking) {
      return '';
    }

    return `${this.confirmationBooking.service} with ${this.confirmationBooking.barber} · ${this.bookingState.formatDate(this.confirmationBooking.date)} at ${this.confirmationBooking.time}`;
  }
}
