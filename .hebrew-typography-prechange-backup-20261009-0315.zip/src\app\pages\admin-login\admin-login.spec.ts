import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';
import { AdminLogin } from './admin-login';
import { Auth } from '../../services/auth';

describe('AdminLogin', () => {
  let component: AdminLogin;
  let auth: { login: ReturnType<typeof vi.fn> };
  let navigate: ReturnType<typeof vi.fn>;

  beforeEach(async () => {
    auth = { login: vi.fn(() => of({ token: 'test-token' })) };
    navigate = vi.fn(() => Promise.resolve(true));

    await TestBed.configureTestingModule({
      imports: [AdminLogin],
      providers: [
        { provide: Auth, useValue: auth },
        { provide: Router, useValue: { navigate } }
      ]
    }).compileComponents();

    const fixture: ComponentFixture<AdminLogin> = TestBed.createComponent(AdminLogin);
    component = fixture.componentInstance;
  });

  it('navigates to the protected dashboard after a successful password login', async () => {
    component.password = 'correct-password';
    await component.login();

    expect(auth.login).toHaveBeenCalledWith('correct-password');
    expect(navigate).toHaveBeenCalledWith(['/admin'], { replaceUrl: true });
  });

  it('shows a clear error when the password is rejected', async () => {
    auth.login.mockReturnValueOnce(throwError(() => ({ status: 401, error: { message: 'Invalid admin credentials.' } })));
    component.password = 'wrong-password';
    await component.login();

    expect(component.loginError).toBe('Invalid admin credentials.');
  });
});
