import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { getApiErrorMessage } from '../../services/api-error';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-login.html',
  styleUrl: './admin-login.css'
})
export class AdminLogin {
  private auth = inject(Auth);
  private router = inject(Router);

  password = '';
  loginError = '';
  isSubmitting = false;

  async login() {
    if (this.isSubmitting) {
      return;
    }

    this.loginError = '';
    if (!this.password) {
      this.loginError = 'Enter the admin password.';
      return;
    }

    try {
      this.isSubmitting = true;
      await firstValueFrom(this.auth.login(this.password));
      this.password = '';
      await this.router.navigate(['/admin'], { replaceUrl: true });
    } catch (error) {
      this.loginError = getApiErrorMessage(error, 'Invalid admin credentials.');
      this.password = '';
    } finally {
      this.isSubmitting = false;
    }
  }
}
