import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { NEVER } from 'rxjs';
import { vi } from 'vitest';

import { Home } from './home';
import { BookingApiService } from '../../services/booking-api';
import { BookingStateService } from '../../services/booking-state';

describe('Home', () => {
  let component: Home;
  let fixture: ComponentFixture<Home>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home],
      providers: [
        provideRouter([]),
        { provide: BookingApiService, useValue: { getServices: () => NEVER, getBarbers: () => NEVER, getAvailabilityDates: () => NEVER, getAvailabilitySlots: () => NEVER } },
      ],
    }).compileComponents();
    const bookingState = TestBed.inject(BookingStateService);
    bookingState.setServices([
      { id: 'signature-cut', name: 'Signature Cut', description: '', duration: 30, price: 90, badge: '', bestFor: '', popularity: '', active: true },
      { id: 'beard-detail', name: 'Beard Detail', description: '', duration: 20, price: 55, badge: '', bestFor: '', popularity: '', active: true },
      { id: 'full-grooming', name: 'Full Grooming', description: '', duration: 45, price: 135, badge: '', bestFor: '', popularity: '', active: true },
      { id: 'wash-style', name: 'Wash and Style', description: '', duration: 30, price: 70, badge: '', bestFor: '', popularity: '', active: true },
    ]);
    bookingState.setBarbers([{ id: 'ahmed', name: 'Ahmed', title: 'Fade Specialist', rating: 4.9, reviews: 168, specialty: 'Clean fades', availability: '', image: '/img/jpg1.png', nextAvailable: 'Available today' }]);
    fixture = TestBed.createComponent(Home);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('shows a focused booking CTA and only three service previews', () => {
    const element: HTMLElement = fixture.nativeElement;
    expect(element.querySelector('.hero-button')?.textContent).toContain('Book Appointment');
    expect(element.querySelectorAll('.service-card')).toHaveLength(3);
  });

  it('starts a new booking with the fastest available barber preference', () => {
    const startNewBooking = vi.spyOn((component as any).bookingState, 'startNewBooking');
    component.startBooking();
    expect(startNewBooking).toHaveBeenCalledWith({ barberPreference: 'any' });
  });
});
