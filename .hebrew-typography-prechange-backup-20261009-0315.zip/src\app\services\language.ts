import { DOCUMENT } from '@angular/common';
import { Injectable, inject, signal } from '@angular/core';

export type AppLanguage = 'en' | 'he';

const languageStorageKey = 'northBarberLanguage';

const hebrew: Record<string, string> = {
  'Book Appointment': 'קביעת תור',
  'Language selection': 'בחירת שפה', 'English': 'English',
  'Book Same Again': 'קביעת אותו תור שוב',
  'Booking complete': 'התור נקבע',
  'Your appointment has been confirmed:': 'התור שלך אושר:',
  'Book your next haircut in minutes.': 'קובעים את התספורת הבאה תוך דקות.',
  'Next available:': 'התור הקרוב:',
  'No account needed. SMS confirmation. Pay in shop.': 'אין צורך בחשבון. אישור ב-SMS. תשלום במספרה.',
  'Services': 'שירותים', 'Choose your service': 'בחירת שירות', 'View all services': 'כל השירותים',
  'Our barbers': 'הספרים שלנו', 'Meet the team': 'הכירו את הצוות',
  'Downtown · Open daily 9:30 AM–7:00 PM': 'מרכז העיר · פתוח מדי יום 9:30–19:00',
  'Pay in shop': 'תשלום במספרה.', 'Booking progress': 'התקדמות ההזמנה',
  'Choose': 'בחירה', 'Your details': 'הפרטים שלך', 'Confirm': 'אישור',
  'Step 1 of 3': 'שלב 1 מתוך 3', 'Step 2 of 3': 'שלב 2 מתוך 3', 'Step 3 of 3': 'שלב 3 מתוך 3',
  'Choose a service': 'בחירת שירות', 'We’ll find the soonest available barber.': 'נמצא את הספר הזמין הקרוב ביותר.',
  'Pick a day and time': 'בחירת יום ושעה', 'Change service': 'החלפת שירות',
  'Best available barber': 'הספר הזמין ביותר', 'Choose a barber': 'בחירת ספר',
  'Quick time choices': 'בחירות שעה מהירות', 'Earliest': 'הקרוב ביותר', 'Today': 'היום',
  'Tomorrow': 'מחר', 'After work': 'אחרי העבודה', 'Choose appointment date': 'בחירת תאריך לתור',
  'Closed': 'סגור', 'Full': 'מלא', 'No available days. Please call the shop.': 'אין ימים פנויים. נא להתקשר למספרה.',
  'Loading available times…': 'טוען שעות פנויות…', 'No available times for this day. Try another day.': 'אין שעות פנויות ביום זה. נסו יום אחר.',
  'Optional': 'לבחירתך', 'Choose your barber': 'בחירת ספר', 'Use fastest available': 'הספר הזמין ביותר',
  'Back to time': 'חזרה לבחירת שעה', 'Name': 'שם', 'Your name': 'השם שלך',
  'Phone number': 'מספר טלפון', 'Continue to confirmation': 'המשך לאישור',
  'Confirm your booking': 'אישור התור', 'Edit details': 'עריכת פרטים',
  'Service': 'שירות', 'When': 'מועד', 'Barber': 'ספר', 'Price': 'מחיר',
  'Ready to finish?': 'מוכנים לסיום?', 'Click Confirm Booking to complete your appointment.': 'לחצו על „אישור התור” להשלמת ההזמנה.',
  'SMS confirmation will be sent to': 'אישור ב-SMS יישלח אל', 'Confirming...': 'מאשר…', 'Confirm Booking': 'אישור התור',
  'Current booking': 'התור הנוכחי', 'Your profile': 'הפרטים שלך', 'Name and phone': 'שם ומספר טלפון',
  'Start booking': 'התחלת הזמנה', 'Next available haircut': 'התספורת הפנויה הקרובה',
  'Choose a day and time': 'בחירת יום ושעה', 'Any available barber': 'כל ספר זמין', 'Choose barber': 'בחירת ספר',
  'Choose Service': 'בחירת שירות', 'Choose Time': 'בחירת שעה', 'Continue': 'המשך', 'With': 'אצל',
  'Booking confirmation': 'אישור הזמנה', 'Your appointment has been successfully confirmed.': 'התור שלך אושר בהצלחה.',
  'Returning to the home page in': 'חזרה לדף הבית בעוד', 'seconds.': 'שניות.', 'Confirmation': 'אישור',
  'You’re all set.': 'הכול מוכן.', 'We’ve saved your appointment.': 'התור שלך נשמר.',
  'Booking reminder and payment': 'תזכורת ותשלום', 'Booking actions': 'פעולות לתור', 'Back to Home': 'חזרה לדף הבית',
  'Delete booking': 'ביטול התור', 'Appointment details': 'פרטי התור', 'Duration': 'משך',
  'Booking deleted': 'התור בוטל', 'No active booking is selected.': 'לא נבחר תור פעיל.', 'Book New Appointment': 'קביעת תור חדש',
  'Admin access': 'גישה למנהל', 'Booking dashboard': 'לוח ניהול תורים', 'Admin password': 'סיסמת מנהל',
  'Enter Password': 'הזנת סיסמה', 'Signing in...': 'מתחבר…', 'Enter Dashboard': 'כניסה ללוח הניהול',
  'Operations': 'ניהול', 'Admin dashboard': 'לוח ניהול', 'Customer bookings': 'תורי לקוחות',
  'upcoming': 'קרובים', 'No upcoming bookings.': 'אין תורים קרובים.', 'View all bookings →': 'לכל התורים ←',
  'Working days and hours': 'ימי ושעות פעילות', 'Controls customer slots.': 'קובע את שעות התורים ללקוחות.',
  'Open from': 'פתיחה', 'Open until': 'סגירה', 'Slot length': 'משך משבצת', 'Save Schedule': 'שמירת שעות',
  'Manage barbers': 'ניהול ספרים', 'Shown in customer booking.': 'מוצג בהזמנת הלקוח.', '+ Add Barber': '+ הוספת ספר',
  'Delete': 'מחיקה', 'Barber name': 'שם הספר', 'Title': 'תפקיד', 'Specialty': 'התמחות',
  'Availability text': 'טקסט זמינות', 'Image path': 'נתיב תמונה', 'Available today': 'פנוי היום',
  'Cancel': 'ביטול', 'Add Barber': 'הוספת ספר', 'Manage services': 'ניהול שירותים',
  'Changes update the customer catalog.': 'השינויים מתעדכנים בקטלוג הלקוחות.', '+ Add Service': '+ הוספת שירות',
  'Active': 'פעיל', 'Inactive': 'לא פעיל', 'Edit': 'עריכה', 'Service name': 'שם השירות',
  'Duration (minutes)': 'משך (דקות)', 'Description': 'תיאור', 'Active for customer booking': 'פעיל להזמנת לקוחות',
  'Save Changes': 'שמירת שינויים', 'Premium Cut': 'תספורת פרימיום', 'Service description': 'תיאור השירות',
  'Create booking': 'יצירת תור', 'Create an appointment for a customer.': 'יצירת תור עבור לקוח.', '+ New Booking': '+ תור חדש',
  'Customer name': 'שם הלקוח', 'Phone': 'טלפון', 'Date': 'תאריך', 'Time': 'שעה', 'Notes': 'הערות',
  'Optional notes': 'הערות אופציונליות', 'Create Booking': 'יצירת תור', 'Sign out': 'התנתקות',
  'Back to Admin': 'חזרה למנהל', 'Admin / Bookings': 'מנהל / תורים', 'Booking filters': 'סינון תורים',
  'Upcoming': 'קרובים', 'All active': 'כל הפעילים', 'Search customer, barber, service, or date': 'חיפוש לקוח, ספר, שירות או תאריך',
  'Search bookings': 'חיפוש תורים', 'Loading bookings…': 'טוען תורים…', 'Action': 'פעולה',
  'Cancelling…': 'מבטל…', 'No bookings match this view.': 'אין תורים התואמים לתצוגה זו.',
  'Bookings pages': 'עמודי תורים', 'Previous': 'הקודם', 'Next': 'הבא',
  'Enter the admin password.': 'נא להזין את סיסמת המנהל.', 'Invalid admin credentials.': 'פרטי הכניסה למנהל אינם תקינים.',
  'We could not load available appointments. Please refresh or call the shop.': 'לא הצלחנו לטעון תורים פנויים. רעננו את הדף או התקשרו למספרה.',
  'We could not load available times. Please try another day or call the shop.': 'לא הצלחנו לטעון שעות פנויות. נסו יום אחר או התקשרו למספרה.',
  'We could not confirm your booking. Please try again or call the shop.': 'לא הצלחנו לאשר את התור. נסו שוב או התקשרו למספרה.',
  'That time is no longer available. Please choose another time.': 'השעה הזו אינה זמינה עוד. נא לבחור שעה אחרת.',
};

@Injectable({ providedIn: 'root' })
export class LanguageService {
  private readonly document = inject(DOCUMENT);
  readonly language = signal<AppLanguage>(this.readInitialLanguage());

  constructor() { this.applyDocumentLanguage(this.language()); }

  setLanguage(language: AppLanguage) {
    this.language.set(language);
    try { localStorage.setItem(languageStorageKey, language); } catch {}
    this.applyDocumentLanguage(language);
  }

  text(value: string) { return this.language() === 'he' ? hebrew[value] || value : value; }

  private readInitialLanguage(): AppLanguage {
    try { return localStorage.getItem(languageStorageKey) === 'he' ? 'he' : 'en'; } catch { return 'en'; }
  }

  private applyDocumentLanguage(language: AppLanguage) {
    this.document.documentElement.lang = language;
    this.document.documentElement.dir = language === 'he' ? 'rtl' : 'ltr';
  }
}
